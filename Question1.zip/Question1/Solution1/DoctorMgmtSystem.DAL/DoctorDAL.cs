﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem1.Exception1;

namespace DoctorMgmtSystem.DAL
{
    public class DoctorDAL
    {
        public static List<Doctors> objDoctorsList = new List<Doctors>();

        public bool AddDoctorDAL(Doctors ObjDoctors)
        {
            bool doctorAdded = false;
            try
            {
                objDoctorsList.Add(ObjDoctors);
                doctorAdded = true;
            }
            catch (SystemException objEx)
            {
                throw new DoctorMgmtSystemException(objEx.Message);
            }
            return doctorAdded;
        }

        public Doctors SearchDoctorDAL(int regino)
        {
            Doctors objDoctor = null;

            try
            {
                objDoctor =objDoctorsList .Find(doctor => doctor.RegNo.Equals(regino));

            }
            catch (SystemException objEx)
            {
                throw new DoctorMgmtSystemException (objEx.Message);
            }
            return objDoctor;
        }


    }
}
