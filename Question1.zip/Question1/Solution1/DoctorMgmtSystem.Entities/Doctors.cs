﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorMgmtSystem.Entities
{
    public class Doctors
    {
        //declare variables
        int _regNo, _timing, _contactNo;
        string _city,  _address;
        char _name, _area;


        //create properties
        public int RegNo
        {
            get
            {
                return _regNo;
            }
            set
            {
                _regNo = value;
            }
        }

        public int Timing
        {
            get
            {
                return _timing;
            }
            set
            {
               _timing = value;
            }
        }

        public int ContactNo
        {
            get
            {
                return _contactNo;
            }
            set
            {
               _contactNo = value;
            }
        }

        public char Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }

        public char Area
        {
            get
            {
                return _area;
            }
            set
            {
               _area = value;
            }
        }

        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }


    }
}
