﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem.DAL;
using DoctorMgmtSystem1.Exception1;

namespace DoctorMgmtSystem.BL
{
    public class DoctorBL
    {
        private static bool ValidateDoctor(Doctors objDoctor)
        {

            StringBuilder objSB = new StringBuilder();
            bool validDoc = true;
            if (Convert.ToString( objDoctor.RegNo)== string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " Registraion number required: ");
            }
            if (objDoctor.RegNo.ToString().Length < 7 || objDoctor.RegNo.ToString().Length >7)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + "enter 7 digits only");
            }

            if (Convert.ToString(objDoctor.Name) == string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + "Doctor name required: ");
            }
            if (!Char.IsLetter(objDoctor.Name))
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " Doctor should be of type character only: ");
            }


            if (Convert.ToString(objDoctor.Area) == string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " Area required: ");
            }
            if (!Char.IsLetter(objDoctor.Area))
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " Area of specialization should be of type character only: ");
            }

            if (Convert.ToString(objDoctor.City) == string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " city name required: ");
            }

            if (Convert.ToString(objDoctor.Address) == string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " address  required: ");
            }
            if (Convert.ToString(objDoctor.Timing) == string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + " Timing is required: ");
            }

            if (Convert.ToString(objDoctor.ContactNo) == string.Empty)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + "ContactNo required: ");
            }
            if (objDoctor.ContactNo.ToString().Length < 10 || objDoctor.ContactNo.ToString().Length > 10)
            {
                validDoc = false;
                objSB.Append(Environment.NewLine + "enter 10 digits only");
            }
            if (validDoc == false)
                throw new DoctorMgmtSystemException(objSB.ToString());
            return validDoc;
        }


        public static bool AddDoctorBL(Doctors objDoctor)
        {
            bool drAdded = false;
            try
            {
                if (ValidateDoctor(objDoctor))
                {
                    DoctorDAL objDoctorDal = new DoctorDAL();
                    drAdded = objDoctorDal.AddDoctorDAL(objDoctor);
                }
            }
            catch (DoctorMgmtSystemException objEmpMgmtExc)
            {
                throw objEmpMgmtExc;   //rethrow it in upper layers
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return drAdded;
        }

        public static Doctors SearchDoctorBL(int regno)
        {
            Doctors drSearch = null;
            try
            {
                DoctorDAL objDoctorDAL = new DoctorDAL();
                drSearch = objDoctorDAL.SearchDoctorDAL(regno);
            }
            catch (DoctorMgmtSystemException objEmpMgmtExc)
            {
                throw objEmpMgmtExc;   //rethrow it in upper layers(handled in main)
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return drSearch;
        }


    }
}
